package com.example.swingmining;

import java.util.Optional;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Turns normal "hold to mine" progress into discrete swings.
 *
 * Break progress per tick is normally speed / hardness / 30 (or 100 with the
 * wrong tool). We override the speed so the per-tick progress is 0 most of the
 * time and jumps on each swing tick.
 */
public class BreakHandler {

    // The server accepts the client's "block finished" message when
    // progress * (ticks elapsed + 1) >= 0.7, but must never reach 1.0 on the
    // very first tick (that would instantly break the block). 0.7 satisfies both.
    private static final float SERVER_PROGRESS = 0.7F;

    // Client-only swing tracking.
    private static BlockPos clientPos = null;
    private static int clientStart = 0;
    private static int clientLastSeen = -100;

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onBreakSpeed(PlayerEvent.BreakSpeed event) {
        Player player = event.getEntity();
        Optional<BlockPos> posOpt = event.getPosition();
        if (posOpt.isEmpty()) {
            return;
        }
        BlockPos pos = posOpt.get();
        BlockState state = event.getState();
        Level level = player.level();

        float hardness = state.getDestroySpeed(level, pos);
        if (hardness <= 0.0F) {
            // Unbreakable (-1) or instant-break blocks stay as they are.
            return;
        }
        if (player.getAbilities().instabuild) {
            return;
        }

        float progress;
        if (level.isClientSide()) {
            progress = clientProgress(player, pos);
        } else {
            progress = SERVER_PROGRESS;
        }

        int divisor = player.hasCorrectToolForDrops(state) ? 30 : 100;
        event.setNewSpeed(progress * hardness * divisor);
    }

    private static float clientProgress(Player player, BlockPos pos) {
        int now = player.tickCount;
        if (clientPos == null || !pos.equals(clientPos) || now - clientLastSeen > 1 || now < clientLastSeen) {
            clientPos = pos.immutable();
            clientStart = now;
        }
        clientLastSeen = now;

        int elapsed = now - clientStart;
        int interval = SwingConfig.INTERVAL.get();
        int hits = SwingConfig.HITS.get();

        // Swings happen at elapsed = 1, 1 + interval, 1 + 2*interval, ...
        if (elapsed < 1 || (elapsed - 1) % interval != 0) {
            return 0.0F;
        }
        int swing = (elapsed - 1) / interval + 1;
        if (swing >= hits) {
            return 1.0F;
        }
        return 1.0F / hits;
    }
}

package com.example.swingmining.client;

import java.util.Locale;
import java.util.Optional;

import com.example.swingmining.SwingConfig;

import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import me.shedaniel.clothconfig2.gui.entries.IntegerSliderEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SwingConfigScreen {

    /** Ticks -> seconds text, e.g. 10 -> "0.50". */
    private static String seconds(double ticks) {
        return String.format(Locale.ROOT, "%.2f", ticks / 20.0);
    }

    public static Screen create(Screen parent) {
        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Component.literal("Swing Mining"))
                .setSavingRunnable(SwingConfig.SPEC::save);

        ConfigEntryBuilder entries = builder.entryBuilder();
        ConfigCategory general = builder.getOrCreateCategory(Component.literal("General"));

        general.addEntry(entries.startTextDescription(
                Component.literal("Calculator: 20 ticks = 1 second. "
                        + "The slider shows the delay in seconds, and hovering it shows the total time per block."))
                .build());

        // Swings needed to break a block.
        IntegerSliderEntry hitsEntry = entries
                .startIntSlider(Component.literal("Swings to break a block"), SwingConfig.HITS.get(), 1, 20)
                .setDefaultValue(3)
                .setTextGetter(v -> Component.literal(v + (v == 1 ? " swing" : " swings")))
                .setTooltip(Component.literal("How many swings it takes to break any block."))
                .setSaveConsumer(SwingConfig.HITS::set)
                .build();

        // Cooldown between swings, with a live "ticks = seconds" readout.
        IntegerSliderEntry intervalEntry = entries
                .startIntSlider(Component.literal("Delay between swings"), SwingConfig.INTERVAL.get(), 2, 100)
                .setDefaultValue(10)
                .setTextGetter(v -> Component.literal(v + " ticks  =  " + seconds(v) + " s"))
                .setTooltipSupplier(v -> {
                    int hits = hitsEntry.getValue();
                    double totalTicks = (double) (hits - 1) * v;
                    return Optional.of(new Component[] {
                            Component.literal("Delay between swings: " + seconds(v) + " s"),
                            Component.literal("Swings: " + hits),
                            Component.literal("Time to break a block: about " + seconds(totalTicks) + " s")
                    });
                })
                .setSaveConsumer(SwingConfig.INTERVAL::set)
                .build();

        general.addEntry(hitsEntry);
        general.addEntry(intervalEntry);

        return builder.build();
    }
}

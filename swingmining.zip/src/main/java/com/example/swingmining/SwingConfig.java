package com.example.swingmining;

import net.minecraftforge.common.ForgeConfigSpec;

public class SwingConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue HITS;
    public static final ForgeConfigSpec.IntValue INTERVAL;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        HITS = builder
                .comment("How many swings it takes to break a block.")
                .defineInRange("hitsRequired", 3, 1, 20);
        INTERVAL = builder
                .comment("Ticks of cooldown between swings (20 ticks = 1 second).")
                .defineInRange("swingIntervalTicks", 10, 2, 100);
        SPEC = builder.build();
    }
}

package com.example.swingmining;

import com.example.swingmining.client.ClientInit;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(SwingMining.MODID)
public class SwingMining {
    public static final String MODID = "swingmining";

    public SwingMining() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, SwingConfig.SPEC);
        MinecraftForge.EVENT_BUS.register(BreakHandler.class);

        // Registers the Cloth Config screen (client only, so servers never load it).
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientInit::register);
    }
}
